import "firebase/compat/database";
import "firebase/compat/app";
import firebase from "firebase/compat/app";
import "firebase/compat/auth"
import 'firebase/compat/storage';

const firebaseConfig = {
  apiKey: "AIzaSyCa8yk6QTw8A4phIQNSbq0Mhcn3vg0bShM",
  authDomain: "m-city-1c5f9.firebaseapp.com",
  projectId: "m-city-1c5f9",
  storageBucket: "m-city-1c5f9.appspot.com",
  messagingSenderId: "866946360895",
  appId: "1:866946360895:web:e021a91a8e6b20aa88fa8a",
  measurementId: "G-Q52SH7SEH0",
};

firebase.initializeApp(firebaseConfig);
const firebaseMatches = firebase.database().ref("matches");
const firbasePromotions = firebase.database().ref("promotions");
const firebaseTeams = firebase.database().ref("teams");
const firebaseDB = firebase.database()
const firebasePlayers = firebase.database().ref("players");
export { firebase,firebasePlayers, firebaseMatches ,firbasePromotions,firebaseTeams,firebaseDB};