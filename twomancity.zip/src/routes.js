import { Switch, Route } from "react-router-dom";
import Layout from "./Hoc/Layout";
import Home from "./Components/home/index";
import SignIn from "./Components/sigin";
import Dashboard from "./Components/admin/Dashboard";
import PrivateRoutes from "./Components/authRoutes/PrivateRoutes";
import PublicRoutes from "./Components/authRoutes/PublicRoutes";
import AdminMatches from "./Components/matches/admin_matches";
import AddEditMatch from './Components/matches/addEditMatch'
import AdminPlayers from './Components/admin/players'
import AddEditPlayers from './Components/admin/players/addEditPlayers'
import TheTeam from './Components/theTeam/theTeam'
import TheMatches from './Components/theMatches/index'
import NotFound from './Components/ui/not_found'


const Routes = (props) => {
  return (
    <div>
      <Layout>
        <Switch>
          <PrivateRoutes {...props} path="/admin_players/add_players" exact component={AddEditPlayers}/>
          <PrivateRoutes {...props} path="/admin_players" exact component={AdminPlayers}/>
          <PrivateRoutes {...props} path="/admin_players/add_players/:id" exact component={AddEditPlayers}/>
          <PrivateRoutes {...props} path="/Dashboard" exact component={Dashboard} />
          <PrivateRoutes {...props} path="/admin_matches" exact component={AdminMatches} />
          <PrivateRoutes {...props} path="/Edit_Matches/:id" exact component={AddEditMatch}/>
          <PublicRoutes {...props} restricted={true} path="/sign_in" exact component={SignIn}/>
          <Route {...props} exact component={TheTeam} restricted={false} path="/the_team" />
          <Route {...props} exact component={TheMatches} restricted={false} path="/the_match" />
          <Route {...props} exact component={NotFound} restricted={false} />
        </Switch>
      </Layout>
    </div>
  );
};

export default Routes;
