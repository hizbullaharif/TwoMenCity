import React from 'react'
import Featured from './featured'
import Matches from './matches'
import Meetplayer from './meetplayer'
import Promotion from './promotion'

const Home = ()=> {
    return (
        <div className="bck_blue">
            <Featured/>
            <Matches/>
            <Meetplayer/>
            <Promotion/>
        </div>
    )
}

export default Home
