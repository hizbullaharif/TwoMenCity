import React, { Component } from "react";
import Fade from "react-reveal/Fade";
import FormField from "../../ui/formField";
import { validate } from "../../ui/misc";
import { firbasePromotions } from "../../../firebase";

class Enroll extends Component {
  state = {
    formError: false,
    formSuccess: "",
    formData: {
      email: {
        element: "input",
        value: "",
        config: {
          name: "email_input",
          type: "email",
          placeholder: "Enter your email",
        },
        validation: {
          required: true,
          email: true,
        },
        valid: false,
        validationMessage: "",
      },
    },
  };

  updateForm(element) {
    const newformData = { ...this.state.formData };
    const newElement = { ...newformData[element.id] };

    newElement.value = element.event.target.value;

    let validData = validate(newElement);
    newElement.valid = validData[0];
    newElement.validationMessage = validData[1];
    newformData[element.id] = newElement;

    console.log(validData);

    this.setState({
      formData: newformData,
    });
  }

  resetFormSuccess(type) {
    const newformData = { ...this.state.formData };
    for (let key in newformData) {
      newformData[key].value = "";
      newformData[key].valid = false;
      newformData[key].validationMessage = "";
    }
    this.setState({
      formError: false,
      formData: newformData,
      formSuccess: type ? "Congratulations" : "Already on Databse",
    });
    this.succesMessage();
  }

  succesMessage() {
    setTimeout(() => {
      this.setState({
        formSuccess: "",
      });
    });
  }

  submitForm(event) {
    event.preventDefault();
    let dataTosubmit = {};
    let formIsValid = true;
    for (let key in this.state.formData) {
      dataTosubmit[key] = this.state.formData[key].value;
      formIsValid = this.state.formData[key].valid && formIsValid;
    }
    
    if (formIsValid) {
      firbasePromotions
        .orderByChild("email")
        .equalTo(dataTosubmit.email)
        .once("value")
        .then((snapshot) => {
          console.log(snapshot.val());
          if (snapshot.val() === null) {
            firbasePromotions.push(dataTosubmit);
            this.resetFormSuccess(true);
          } else {
            this.resetFormSuccess(false);
          }
        });

      //   this.resetFormSuccess(dataTosubmit)
    } else {
      this.setState({
        formError: true,
      });
    }
  }

  render() {
    return (
      <Fade>
        <div className="enroll_wrapper">
          <form onSubmit={(event) => this.submitForm(event)}>
            <div className="enroll_title">Enter your Email</div>
            <div className="enroll_input">
              <FormField
                id={"email"}
                formData={this.state.formData.email}
                change={(element) => this.updateForm(element)}
              />
              {this.state.formError ? (
                <div className="error_label">Some Thing is wrong</div>
              ) : null}
              <div className="success_label">{this.state.formSuccess}</div>
              <button type="submit" onClick={(event) => this.submitForm(event)}>
                Enroll
              </button>
            </div>
          </form>
        </div>
      </Fade>
    );
  }
}

export default Enroll;
