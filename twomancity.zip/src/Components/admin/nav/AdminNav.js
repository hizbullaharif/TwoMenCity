import React from "react";
import { ListItem } from "@material-ui/core";
import { Link } from "react-router-dom";
import { firebase } from "../../../firebase";

const Adminnav = () => {
  const links = [
    {
      title: "Matches",
      linkto: "/admin_matches",
    },
    {
      title: "Add Match",
      linkto: "/Edit_Matches/:id",
    },
    {
      title: "Players",
      linkto: "/admin_players/",
    },
    {
      title: "Add Players",
      linkto: "/admin_players/add_players",
    },
  ];

  const style = {
    color: "#ffffff",
    fontWeight: "300",
    borderBottom: "1px solid #353535",
  };

  const renderItems = () =>
    links.map((link) => (
      <Link to={link.linkto} key={link.title}>
        <ListItem button style={style}>
          {link.title}
        </ListItem>
      </Link>
    ));

  const logoutHanler = () => {
    firebase
      .auth()
      .signOut()
      .then(
        () => {
          console.log("Logged out");
        },
        (error) => console.log(error)
      );
  };

  return (
    <div>
      {renderItems()}
      <ListItem button style={style} onClick={(event) => logoutHanler()}>
        Logout
      </ListItem>
    </div>
  );
};

export default Adminnav;
