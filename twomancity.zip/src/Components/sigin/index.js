import React, { Component } from 'react'
import Fade from 'react-reveal/Fade'
import FormField from '../ui/formField'
import {validate} from '../ui/misc'
import {firebase} from '../../firebase'

class SignIn extends Component {
    state = {
        formError: false,
        formSuccess: "",
        formData: {
          email: {
            element: "input",
            value: "",
            config: {
              name: "email_input",
              type: "email",
              placeholder: "Enter your email",
            },
            validation: {
              required: true,
              email: true,
            },
            valid: false,
            validationMessage: "",
          },
          password: {
            element: "input",
            value: "",
            config: {
              name: "password_input",
              type: "password",
              placeholder: "Enter your password",
            },
            validation: {
              required: true,
              email: true,
            },
            valid: false,
            validationMessage: "",
          },
        },
      };

      updateForm(element) {
        const newformData = { ...this.state.formData };
        const newElement = { ...newformData[element.id] };
    
        newElement.value = element.event.target.value;
    
        let validData = validate(newElement);
        newElement.valid = validData[0];
        newElement.validationMessage = validData[1];
        newformData[element.id] = newElement;
    
        this.setState({
          formData: newformData,
        });
      }
      
      submitForm(event) {
        event.preventDefault();
        let dataTosubmit = {};
        let formIsValid = true;
    
        for (let key in this.state.formData) {
          dataTosubmit[key] = this.state.formData[key].value;
          formIsValid = this.state.formData[key].valid && formIsValid;
        }
    
        if (formIsValid) {
            firebase.auth()
            .signInWithEmailAndPassword(
                dataTosubmit.email,
                dataTosubmit.password
            ).then(()=>{
                console.log("USer is auth")
            }).catch(error=>{
                this.setState({
                    formError:true
                })
            })
          
        } else {
          this.setState({
            formError: true,
          });
        }
      }
      
    render() {
        return (
            
                <div className="container">
                    <div className="signin_wrapper" style={{margin:'100px'}}>
                        <form onSubmit={(event) =>this.onSubmitForm(event)}>
                            <h2>Please Login</h2>
                            
                            <FormField
                                id={'email'}
                                formData={this.state.formData.email}
                                change={(element)=>this.updateForm(element)}
                            />

                            <FormField
                                id={'password'}
                                formData={this.state.formData.password}
                                change={(element)=>this.updateForm(element)}
                            />
                            {this.state.formError?
                                <div className="error_label">Something is wrong Try again</div>
                                :null
                            }
                            <button onClick={(event)=>this.submitForm(event)}>Login</button>
                        </form>
                    </div>
                </div>
        )
    }
}

export default SignIn