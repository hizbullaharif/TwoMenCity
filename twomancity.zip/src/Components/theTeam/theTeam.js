import React from 'react';
import PlayerCard from '../ui/PlayerCard';
import Fade from 'react-reveal/Fade'
import { useState ,useEffect} from 'react';

import Stripes from '../../Resources/images/stripes.png'
import {firebase,firebasePlayers} from '../../firebase'
import {Promise} from 'core-js'
import {firebaseLooper} from '../ui/misc'

const TheTeam = () => {
    const [loading,setLoading]=useState(true)
    const [players,setPlayers]=useState()

    useEffect(() => {
        firebasePlayers.once('value').then(snapshot=>{
            const players = firebaseLooper(snapshot)
            let promises = []

            for (let key in players){
                promises.push(
                    new Promise ((resolve,reject)=>{
                        firebase.storage().ref('players')
                        .child(players[key].image).getDownloadURL()
                        .then(url => {
                            players[key].url =url
                            resolve();
                        })
                        
                    })
                )
            }
            Promise.all(promises).then(()=>{
                setLoading(false)
                setPlayers(players)
            })
            console.log(players)
        })
    })

    const showplayersByCategory = (category) => (
        players ?
            players.map((player,i)=>{
                return player.position === category ?
                    <Fade left delay={i*20} key={i}>
                        <div className="item">
                            <PlayerCard
                                number={31}
                                name={"hizb"}
                                lastname={"khan"}
                                bck={player.url}
                            />
                        </div>
                    </Fade>
                :null
            })
        :null
    )




    return (
        <>
        
          <div className="the_team_container"
                style={{
                    background:`url(${Stripes}) repeat`
                }}
            >
                { loading ?
                    <div>
                        <div className="team_category_wrapper">
                            <div className="title">Keepers</div>
                            <div className="team_cards">
                                {showplayersByCategory('Keeper')}
                              
                            </div>
                        </div>

                        <div className="team_category_wrapper">
                            <div className="title">Defence</div>
                            <div className="team_cards">
                                {showplayersByCategory('Defence')}
                            </div>
                        </div>

                        <div className="team_category_wrapper">
                            <div className="title">Midfield</div>
                            <div className="team_cards">
                                {showplayersByCategory('Midfield')}
                            </div>
                        </div>

                        <div className="team_category_wrapper">
                            <div className="title">Strikers</div>
                            <div className="team_cards">
                                {showplayersByCategory('Striker')}
                            </div>
                        </div>

                    </div>
                    :null
                }
                
            </div>  
        </>
    );
};

export default TheTeam;